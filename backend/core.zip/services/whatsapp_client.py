"""
Thin wrapper around Meta's WhatsApp Cloud API for sending replies.
Receiving messages happens via the webhook in routes/whatsapp.py — this file
is only for the outgoing side (bot -> user).
"""

import os
import httpx

GRAPH_API_VERSION = "v20.0"


def _api_url() -> str:
    phone_number_id = os.environ.get("WHATSAPP_PHONE_NUMBER_ID")
    if not phone_number_id:
        raise RuntimeError("WHATSAPP_PHONE_NUMBER_ID is not set.")
    return f"https://graph.facebook.com/{GRAPH_API_VERSION}/{phone_number_id}/messages"


def send_whatsapp_message(to: str, text: str) -> None:
    """
    Send a plain text WhatsApp message to a phone number (in international
    format, no "+", e.g. "2348012345678" — this is the format WhatsApp's
    webhook gives us the sender's number in, so we can reuse it directly).
    """
    access_token = os.environ.get("WHATSAPP_ACCESS_TOKEN")
    if not access_token:
        raise RuntimeError("WHATSAPP_ACCESS_TOKEN is not set.")

    payload = {
        "messaging_product": "whatsapp",
        "to": to,
        "type": "text",
        "text": {"body": text},
    }
    headers = {"Authorization": f"Bearer {access_token}"}

    response = httpx.post(_api_url(), json=payload, headers=headers, timeout=15)
    response.raise_for_status()