"""
WhatsApp channel adapter.

Two responsibilities:
  GET  /webhooks/whatsapp  -> Meta's one-time verification handshake
  POST /webhooks/whatsapp  -> incoming message events

Both reuse the same core assistant logic as the website (core/assistant.py)
and the same conversations/messages tables, tagged with channel="whatsapp".
"""

import hashlib
import hmac
import os

from flask import Blueprint, request, jsonify

from core.assistant import get_assistant_reply
from models.db import (
    SessionLocal,
    get_or_create_conversation,
    get_recent_messages,
    save_message,
    already_processed,
    mark_processed,
)
from services.whatsapp_client import send_whatsapp_message

whatsapp_bp = Blueprint("whatsapp", __name__)

HISTORY_LIMIT = 10


@whatsapp_bp.get("/webhooks/whatsapp")
def verify_webhook():
    """
    Meta calls this once when you register the webhook URL in the developer
    dashboard, to confirm you actually control this server. It sends a
    challenge value and expects it echoed back — but only if our verify
    token matches the one we configured on Meta's side.
    """
    mode = request.args.get("hub.mode")
    token = request.args.get("hub.verify_token")
    challenge = request.args.get("hub.challenge")

    expected_token = os.environ.get("WHATSAPP_VERIFY_TOKEN")

    if mode == "subscribe" and token and expected_token and token == expected_token:
        return challenge, 200

    return "Verification failed", 403


def _verify_signature(raw_body: bytes) -> bool:
    """
    Confirms this request actually came from Meta, not someone who found the
    webhook URL and is sending fake messages to run up your Groq usage or
    inject content. Meta signs every webhook POST with your app secret;
    we recompute the same signature and compare.
    """
    app_secret = os.environ.get("WHATSAPP_APP_SECRET")
    if not app_secret:
        # Fail closed: if we can't verify, we don't trust the request.
        return False

    signature_header = request.headers.get("X-Hub-Signature-256", "")
    if not signature_header.startswith("sha256="):
        return False

    expected = hmac.new(app_secret.encode(), raw_body, hashlib.sha256).hexdigest()
    provided = signature_header.removeprefix("sha256=")
    return hmac.compare_digest(expected, provided)


@whatsapp_bp.post("/webhooks/whatsapp")
def receive_message():
    if not _verify_signature(request.get_data()):
        return jsonify({"error": "invalid_signature"}), 403

    payload = request.get_json(silent=True) or {}

    # Meta's payload shape: entry[].changes[].value.messages[]
    # We defensively walk it since malformed/unexpected payloads (status
    # updates, read receipts, etc.) are also delivered to this same webhook.
    try:
        entries = payload.get("entry", [])
        for entry in entries:
            for change in entry.get("changes", []):
                value = change.get("value", {})
                messages = value.get("messages", [])
                for message in messages:
                    _handle_incoming_message(message)
    except Exception as e:  # noqa: BLE001
        # Log and still return 200 — returning an error here makes Meta
        # retry the same (possibly malformed) payload repeatedly.
        print(f"Error processing WhatsApp webhook: {e}")

    # Meta expects a fast 200 regardless of what we did with the message;
    # anything else triggers retries.
    return jsonify({"status": "received"}), 200


def _handle_incoming_message(message: dict) -> None:
    message_id = message.get("id")
    from_number = message.get("from")
    text = message.get("text", {}).get("body")

    if not message_id or not from_number or not text:
        return  # not a plain text message (image, audio, etc.) — skip for now

    db = SessionLocal()
    try:
        if already_processed(db, message_id):
            return  # Meta retried a delivery we already handled
        mark_processed(db, message_id)

        convo = get_or_create_conversation(db, channel="whatsapp", external_user_id=from_number)
        recent = get_recent_messages(db, convo.id, limit=HISTORY_LIMIT)
        history = [{"role": m.role, "content": m.content} for m in recent]

        reply = get_assistant_reply(history, text)

        save_message(db, convo.id, "user", text)
        save_message(db, convo.id, "assistant", reply)

        send_whatsapp_message(from_number, reply)
    finally:
        db.close()